package global.quest.bike.repositories;

import org.springframework.data.repository.CrudRepository;

public interface BikeRepository extends CrudRepository{

}
