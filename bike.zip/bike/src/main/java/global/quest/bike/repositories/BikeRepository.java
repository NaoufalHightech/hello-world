package global.quest.bike.repositories;

import global.quest.bike.models.Bike;
import org.springframework.data.jpa.repository.JpaRepository;


public interface BikeRepository extends JpaRepository<Bike, Long>{

}
