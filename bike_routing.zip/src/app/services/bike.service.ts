import { Injectable } from '@angular/core';
import {HttpHeaders} from '@angular/common/http';
import {HttpClient} from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type' : 'application/json'})
}
@Injectable({
  providedIn: 'root'
})
export class BikeService {
  
  constructor(public http: HttpClient) { }
  
  saveBikeDetails(bike){
      let body = JSON.stringify(bike);
      return this.http.post('server/api/v1/bikes', body, httpOptions);
  }

  getBikes():any{
    return this.http.get('server/api/v1/bikes');
  }

}


