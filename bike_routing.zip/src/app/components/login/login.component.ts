
import { Component } from '@angular/core';
import { Validators, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { BikeService } from '../../services/bike.service';

@Component({
  // ...
  selector: 'login-page1',
  templateUrl: './login.component.html'
})
export class LoginComponent {
  username = new FormControl('', [
    Validators.required,
    Validators.minLength(5)
  ]);

  password = new FormControl('', [Validators.required]);

  loginForm: FormGroup = this.builder.group({
    username: this.username,
    password: this.password
  });

  constructor(private builder: FormBuilder, private bikeService: BikeService) { }

  login () {
    console.log(this.loginForm.value);

    this.bikeService.saveBikeDetails(this.loginForm.value);
    
    // Attempt Logging in...
  }
  
}