import { Component, OnInit } from '@angular/core';
import { BikeService } from '../../services/bike.service';
export class Student {
  
  constructor(public id: number,public name: string) {
   
  }
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private bikeService: BikeService) { }

  ngOnInit() {
    this.getAllBikes();
  }

  bikes;

  getAllBikes(){
    this.bikeService.getBikes().subscribe(
      data1 => { this.bikes = data1 },
      err => console.error(err),
      () => console.log('bikes loaded')
    );
  //this.bikes = this.bikeService.getBikes();
  //console.log(this.bikes);
  }

}

 


