import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import {ActivatedRoute} from '@angular/router';
import { BikeService } from '../../services/bike.service';
import { Observable } from 'rxjs/internal/Observable';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private route: ActivatedRoute,private builder: FormBuilder, private bikeService: BikeService) {}

  bike_name = new FormControl('', [
    Validators.required,
    Validators.minLength(5)
  ]);

  bike_email = new FormControl('', [Validators.required]);

  bike_model = new FormControl('', [Validators.required]);

  bikeForm: FormGroup = this.builder.group({
    name: this.bike_name,
    email: this.bike_email,
    model: this.bike_model  
  });

  ngOnInit() {
  }

  saveBikeRegistration(){
  this.bikeService.saveBikeDetails(this.bikeForm.value).subscribe(
    data => {
      this.bikeForm.reset();
      
      return true;
    },
    error => {
      return Observable.throw(error);
    }
  )

  }//method close
}
  



