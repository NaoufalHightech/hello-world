import { NgModule } from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {AdminComponent} from './components/admin/admin.component';
import {HomeComponent} from './components/home/home.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/registration/register.component';


const routes: Routes = [
  {
    path : 'register',
    component : RegisterComponent
  },
{
path : 'Home',
component : HomeComponent
},
{
path : 'admin',
component : AdminComponent
},
{
  path : 'contact-us',
  component : ContactUsComponent
  },
  {
    path : '',
    component : LoginComponent
  }/*,
    {
      path : 'admin/view/:id',
      component : ViewComponent
    }*/


]

@NgModule({
imports : [RouterModule.forRoot(routes)],
exports :[RouterModule]
})

export class AppRoutingModule{}