

var events = require("events"); // events is a core module

var emitter = new events.EventEmitter();

// register for loggedin event(event listener)

emitter.on('loggedIn',function(user){
    console.log('Event : for %s, "LoggedIn"', user);
});

emitter.on('loggingFailed',function(user){
    console.log('Event : for %s", LoggedIn denied and password forgotten"', user);
});

emitter.on('loggingFailed',function(user,pwd){
    console.log('Log : "user- %s", LogIn failed with password %s"',user, pwd);
});


(function(user,pwd){

    if(user === 'User1' && pwd === 'pass'){
        console.log('Login Success');
        emitter.emit('loggedIn',user);
    } else if(user === 'User1' && pwd === undefined){
        console.log('Login failed');
        emitter.emit('loggingFailed',user);
    } else {
        console.log('Login failed');
        emitter.emit('loggingFailed',user,pwd);
    }
})('User1');//('User1','pass1');

