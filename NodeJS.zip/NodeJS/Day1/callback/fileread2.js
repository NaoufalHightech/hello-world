// Non-Blocking code Example

var fs = require("fs");

fs.readFile("input.txt", function(err,data){
    if(err) return console.error(err);

    console.log(data.toString());
});

console.log("Program Ended");

/*
 fileread1.js program blocks until it reads the file 
 and then it proceeds to end the program where as in second example,
 program dose not wait for the file reading but it just proceeded to print "Program Ended" and same 
 time program without blocking continues reading the file.
*/
