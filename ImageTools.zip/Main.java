package com.quest.ecoMicro;

import de.redsix.pdfcompare.PdfComparator;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {

        System.setProperty("sun.java2d.cmm", "sun.java2d.cmm.kcms.KcmsServiceProvider");

        /*String expectedFile = "./pdf_files/client/ExpectedFile.PDF";
        String actualFile = "./pdf_files/client/ActualFile.pdf";
        String diffOutputFile = "./pdf_files/client/clientDiffOutputFile_9";*/

        String expectedFile = "./pdf_files/client/expected.pdf";
        String actualFile = "./pdf_files/client/actual.pdf";
        String diffOutputFile = "./pdf_files/client/sampleDiffFile_1";

        PdfComparator pdfCompObj =	new PdfComparator(expectedFile, actualFile);

        boolean outputTrue = pdfCompObj.compare().writeTo(diffOutputFile);

        if(!outputTrue) {
            System.out.println("PDF is created");
        } else {
            System.out.println("PDF is not created");
        }

    }
}
