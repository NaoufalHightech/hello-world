/*


1. Create a Node.js application for calculating sum and average of two
numbers using file module. The program should follows,
a. The functions are calculateSum(x,y) and calculateAverage(x,y) and save
into calc.js
b. import the publicly available methods of calc.js to a new file called
test.js using file module and calculate sum and average with sample
values
2. Re create the Exercise1 program by using folder as module
3. Re creates the Exercise1 program without using absolute path in require
function. (Hint: use node_modules folder)

*/

// Two functions has to be created.

var calculateSum = function(x,y){
    return x+y;
}

var calculateAverage = function(x,y){
    return (x+y)/2;
}

module.exports = {
    calcSum : calculateSum,
    calcAvg : calculateAverage
}