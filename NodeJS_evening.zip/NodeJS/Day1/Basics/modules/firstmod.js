function printA(){
    console.log("From A");
}
function printB(){
    console.log("From B");
}
function printC(){
    console.log("From C");
}

// a local object has property wich refers to the functionality
// of local module, should be made visible to the consuming logic


module.exports.printA = printA;
module.exports.printB = printB;
module.exports.printC = printC;
module.exports.tempPI = Math.PI;