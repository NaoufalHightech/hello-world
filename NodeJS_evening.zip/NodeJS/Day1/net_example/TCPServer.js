var net = require('net');

function createTCPServer(){
    var PORT = 6969;
    var server = net.createServer();

    server.on('error',function(err){
        console.log(err);
    });

    server.on('listening',function(){
        console.log('server started...');
        var address = this.address();
    });

    server.on('connection',function(socket){
        socket.on('data',function(data){
            console.log(data.toString());
        });
        socket.on('end',function(){
            console.log('-----------client connection closed-------------');
        });
        socket.on('error',function(){
            console.log('-----client send stop message-----------');
        });
        process.stdin.on('data',function(data){
            console.log("server sends data : "+data);
            data = data.trim();
            if(data.toString() === 'stop'){
                process.stdin.pause();
            } else {
                socket.write(data);
            }
        });
    });

   
    process.stdin.setEncoding("utf-8");
    process.stdin.resume();

    server.listen(PORT);
}

createTCPServer();