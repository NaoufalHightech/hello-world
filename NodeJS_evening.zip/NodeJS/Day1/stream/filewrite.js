var fs = require("fs");
var data = 'Quest Global';

// Create a writeable stream
var writeStream = fs.createWriteStream('output.txt');

// Write the data to stream with encoding to be utf-8
writeStream.write(data,'utf-8');

writeStream.end();

writeStream.on('finish',function(){  // This event will be fired only when the end() is called.
    console.log("Write completed");
});

writeStream.on('error',function(error){
    console.log(error.stack);
});


