var fs = require("fs");

// Create a readable stream
var readStream = fs.createReadStream('input.txt');

// Create a writeable stream
var writeStream = fs.createWriteStream('output.txt');

// Pipe the read and write operations
// read input.txt and write data to output.txt
readStream.pipe(writeStream);

readStream.on('end',function(){
    console.log("*****************Reading Ends***************");
});

readStream.on('error',function(err){
    console.log(err.stack);
});
