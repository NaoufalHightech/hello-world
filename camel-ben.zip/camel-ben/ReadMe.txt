Camel Component Project
====================
This Project is a template of the Camel component.
When you create the component project, you need to move the META-INF/services/org/apache/camel/component/helloworld 
file to META-INF/services/org/apache/camel/component/foo where "foo" is the URI scheme for your component and any
 related endpoints created on the fly.

For more help see the Apache Camel documentation

    http://cwiki.apache.org/CAMEL/writing-components.html
    
