
/**
 * 
 */

var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var mysql = require('mysql');

var connection = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : 'Quest1234',
    database : 'test'
});

var query2 = 'select * from test.tbl_user_login where user_name=? and user_pwd=? ';

console.log(query2);


// Create application/x-www-form-urlencoded parser
var urlencodedParser = bodyParser.urlencoded({ extended: true }) 
/* Returns middleware that only parses urlencoded bodies. 
This parser accepts only UTF-8 encoding of the body and supports automatic inflation of gzip and deflate encodings.
*/

app.use(express.static('public'));

app.get('/Login.html', function (req, res) {
   res.sendFile(__dirname + "/" + "Login.html");
})



connection.connect();

app.post('/process_post', urlencodedParser, function (req, res) {

    // Prepare output in JSON format

   var user_name = req.query.user_name;
   console.log("user_name "+user_name);
   var user_pwd = req.query.user_pwd;
   console.log("user_pwd "+user_pwd);

connection.query(query2, [user_name , user_pwd], function(error, results, fields){
    if(error) throw error;
    console.log('The records in employee table : ', results)
});

   response = {
       first_name:req.query.user_name,
       last_name:req.query.user_pwd
   };

    console.log(response);
    res.send(JSON.stringify(response));
 });

connection.end(); 

var server = app.listen(8082, function () {

  var host = server.address().address
  var port = server.address().port

  console.log("Example app listening at http://%s:%s", host, port)

})






