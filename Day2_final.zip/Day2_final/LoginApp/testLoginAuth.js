
/**
 * 
 */

var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var mysql = require('mysql');

var connection = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : 'Quest1234',
    database : 'test'
});


// Create application/x-www-form-urlencoded parser
var urlencodedParser = bodyParser.urlencoded({ extended: true }) 
/* Returns middleware that only parses urlencoded bodies. 
This parser accepts only UTF-8 encoding of the body and supports automatic inflation of gzip and deflate encodings.
*/

app.use(express.static('public'));

app.get('/Login.html', function (req, res) {
   res.sendFile(__dirname + "/" + "Login.html");
})



connection.connect();

app.post('/process_post', urlencodedParser, function (req, res) {

    // Prepare output in JSON format
    
    var user_name = req.body.first_name;
    var user_pwd = req.body.user_pwd;
    

    connection.query('select * from tbl_user_login where user_name = ? and user_pwd=?', 
    [user_name , user_pwd], function(error, results, fields){
        
    if(error){
        console.log("error ocurred",error);
        res.send({
          "code":400,
          "failed":"error ocurred"
        })
        throw error;
    } else {
        if(results.length >0){
            if(results[0].user_pwd == user_pwd){
              res.send({
                "code":200,
                "success":"login sucessfull"
                  });
            }
            else{
              res.send({
                "code":204,
                "success":"Username and password does not match"
                  });
            }
          }
          else{
            res.send({
              "code":204,
              "success":"Username does not exits"
                });
          }
    }
        
    });
    

    console.log(res);
    //res.end(JSON.stringify(response));
 });
 
 connection.end();


var server = app.listen(8081, function () {

  var host = server.address().address
  var port = server.address().port

  console.log("Example app listening at http://%s:%s", host, port)

})
