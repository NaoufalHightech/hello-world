// https://www.npmjs.com/package/mysql

var mysql = require('mysql');

var connection = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : 'Quest1234',
    database : 'test'
});

var user_name = 'raghava';
var user_pwd = 'password1';

connection.connect();

var query = 'select * from tbl_user_login where user_name='+"'"+user_name+"'"+'';

var query1 = 'select * from test.tbl_user_login where user_name=?';
console.log(query1);

var query2 = 'select * from test.tbl_user_login where user_name=? and user_pwd=? ';
console.log(query2);


connection.query(query1, [user_name], function(error, results, fields){
    if(error) throw error;
    console.log('The records in employee table : ', results)
});



connection.query(query2, [user_name , user_pwd], function(error, results, fields){
    if(error) throw error;
    console.log('The records in employee table : ', results)
});

connection.end();

