function hello(req, res){
    res.write("hello world!");
}

//Asynchronous middle ware
function writeHeader(name, value){
    return function(req, res, next) {
        res.setHeader(name, value);
        next();  // continue with next middleware in the stack
    }
}

module.exports = {
        hello : hello,
        writeHeader : writeHeader
}