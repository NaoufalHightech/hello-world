var http = require("http");

function  createServer() {
    var server = http.createServer(function(request, response){
        console.log("HTTP Verb :"+request.method);
        response.writeHead(200, {'Content-Type':'text/html'})
        response.write("<h2>Welecme to Node - HTTP server</h2>");

        response.end();
    });

    server.listen(9090, "127.0.0.1");
    console.log("Server running at http://127.0.0.1:9090/");

}
//createServer();



function createHttpServer(){
    var url = require('url');

    var server = http.createServer(function(request, response){

        var url_parsed = url.parse(request.url, true);
        console.log("HTTP Verb :"+request.method);

        if(request.method == 'GET'){
            handleGetRequest(response, url_parsed);
        } else if(['POST','PUT','DELETE'].indexOf(request.method) >-1){
            handleAPIRequest(request, response, url_parsed, request.method);
        } else {
            response.end('Method not allowed');
        }

    });

    server.listen(9090);
}

handleGetRequest = function(response, url_parsed){
    var fs = require('fs');
    var path = require('path');

    var filePath = path.join(__dirname, '/pages',url_parsed.path);

    fs.exists(filePath, function(exists){

        if(exists){
            response.setHeader("content-type","text/html");
            var readStream = fs.createReadStream(filePath);
            readStream.pipe(response, true);
        } else {
            response.statusCode = 404;
            response.end();
        }

    });

};

handleAPIRequest = function(request, response, url_parsed, method){
    if(url_parsed.path == '/api'){
        response.statusCode = 404;
        response.end();
    } else {
        response.write("Processing.... "+method+" requestful webservice");
        response.end();
    }
};




function createMiddlewareServer(){
    var connect = require ("connect");
    var middlewares = require('./middleware');
    
    var serveStatic = require('serve-static');
    
    var app = connect();
    app.use(middlewares.writeHeader('x-PoweredBy', 'QuEST'));
    
    
    app.use(serveStatic('./pages'));
    app.use (middlewares.hello);
    
    app.listen(9999);
    console.log('http server started and listening port @ port : 9999');
}



createServer();
//createHttpServer();
