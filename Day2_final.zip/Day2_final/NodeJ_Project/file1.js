var fs = require("fs");

//Create a new file using the appendFile() method:

fs.appendFile('input.txt', 'Hello content!', function (err) {
    if (err) throw err;
    console.log('Saved!');
  });

//Create a new, empty file using the open() method

  fs.open('input2.txt', 'w', function (err, file) {
    if (err) throw err;
    console.log('Saved!');
  });

  //Create a new file using the writeFile() method:

  fs.writeFile('input3.txt', 'Hello content!', function (err) {
    if (err) throw err;
    console.log('Saved!');
  });

// Asynchronous - Opening File
console.log("Going to open file!");
fs.
fs.open('input.txt', 'r+', function(err, fd) {
   if (err) {
       return console.error(err);
   }
  console.log("File opened successfully!");     
});

console.log("Going to get file info!");
fs.stat('input.txt', function (err, stats) {
   if (err) {
       return console.error(err);
   }
   console.log(stats);
   console.log("Got file info successfully!");
   
   // Check file type
   console.log("isFile ? " + stats.isFile());
   console.log("isDirectory ? " + stats.isDirectory());    
});


console.log("Going to delete file");
fs.unlink('input.txt', function (err, stats) {
   if (err) {
       return console.error(err);
   }
   console.log("File Deleted successfully!");   
});