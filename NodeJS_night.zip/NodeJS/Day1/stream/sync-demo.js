var fs = require('fs');

var data = fs.readdirSync('C:/Program Files');

console.log('data:', data);

console.log('this comes after');