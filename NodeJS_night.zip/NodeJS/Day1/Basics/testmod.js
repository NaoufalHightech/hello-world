

console.log("-----File Module-----");
var mymod = require("./modules/firstmod");
mymod.printA();
mymod.printB();
mymod.printC();
console.log("Value of PI "+mymod.tempPI);


console.log("------Folder Module----------");
var empMod = require("./modules/my_modules"); // we have to create "package.json" file
var emp = new empMod.Employee(1, "Raghava", 2345);
empMod.login(emp.id);
empMod.logout(emp.id);

////////////
console.log("------node_modules folder----------");
var mathMod = require("myMath"); // we can access "myMath.js", because of "node_modules" folder
console.log(mathMod.addition(10,2));
console.log(mathMod.divide(10,2));