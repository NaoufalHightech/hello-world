
// https://www.npmjs.com/package/mysql

var mysql = require('mysql');

var connection = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : 'Quest1234',
    database : 'test'
});

connection.connect();

connection.query('select * from employee', function(error, results, fields){
    if(error) throw error;
    console.log('The records in employee table : ', results)
});

connection.end();

