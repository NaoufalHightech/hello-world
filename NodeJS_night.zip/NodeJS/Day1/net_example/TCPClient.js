var net = require('net');

function createTCPClient(){
    
    var client = net.createConnection({port: 6969, host:'192.168.141.70'},function(){
        console.log("--------------connected to server---------------");
    });
    
    client.on('data',function(data){
        console.log(data.toString());
    });

    client.on('close',function(){
        console.log("---connection closed---");
    });

    client.on('error',function(){
        console.log("---connection error---");
    });

    client.on('end',function(){
        console.log("---connection end---");
    });

    // below lines from 27 to 37 will enable the user to send data from client to server.

    process.stdin.on('data',function(data){
        console.log("client sends data : "+data);
        data = data.trim();
        if(data.toString() === 'stop'){
            process.stdin.pause();
        } else {
            client.write(data);
        }
    });
    process.stdin.setEncoding("utf-8");
    process.stdin.resume();


}

createTCPClient();