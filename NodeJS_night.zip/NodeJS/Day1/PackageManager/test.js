
console.log("-----File Module-----");
var mymod = require("./module/calc1");
console.log("Addition "+mymod.calcSum(10,2));
console.log("Average "+mymod.calcAvg(10,2));

console.log("------Folder Module----------");
var calMod = require("./my_modules"); // we have to create "package.json" file
console.log("Addition "+mymod.calcSum(10,2));
console.log("Average "+mymod.calcAvg(10,2));


console.log("------node_modules folder----------");
var mathMod = require("calc3"); // we can access "calc.js", because of "node_modules" folder
console.log("Addition "+mathMod.calculateSum(10,2));
console.log("Average "+mathMod.calculateAverage(10,2));



