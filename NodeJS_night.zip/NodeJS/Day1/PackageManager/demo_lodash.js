
// Run below command before execution below program 

// nmp install lodash

var _ = require('lodash');

console.log(_.random(1,81788));

// nodemon is a tool that helps develop node.js based applications by 
// automatically restarting the node application when file changes in the directory are detected.

// npm install -g nodemon
