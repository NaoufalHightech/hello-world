var myModule = require('./my-module.js');

console.log(myModule.myText);